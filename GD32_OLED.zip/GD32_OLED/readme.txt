GD32E230C获取网络上的时间，通过模拟IIC接口和OLED屏通信，同时在OLED屏上显示当前时间。
/*IIC连线：SCL -- PB0   SDA -- PB1*/

