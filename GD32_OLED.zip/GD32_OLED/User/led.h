#ifndef LED_H
#define LED_H

#include "gd32e23x.h"

void LED_Init(void);
	
#endif

